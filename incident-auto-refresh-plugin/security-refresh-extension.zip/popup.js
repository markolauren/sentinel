// Popup script for managing extension settings

document.addEventListener('DOMContentLoaded', () => {
  const enableToggle = document.getElementById('enableToggle');
  const intervalSelect = document.getElementById('intervalSelect');
  const refreshNowBtn = document.getElementById('refreshNow');
  const saveSettingsBtn = document.getElementById('saveSettings');
  const statusText = document.getElementById('statusText');
  
  // Load current settings
  function loadSettings() {
    chrome.storage.sync.get(['enabled', 'interval', 'lastRefresh'], (result) => {
      enableToggle.checked = result.enabled !== undefined ? result.enabled : false;
      intervalSelect.value = result.interval !== undefined ? result.interval : 5;
      updateStatus();
      updateLastRefresh(result.lastRefresh);
    });
  }
  
  // Update last refresh display
  function updateLastRefresh(timestamp) {
    const lastRefreshText = document.getElementById('lastRefreshText');
    if (!timestamp) {
      lastRefreshText.textContent = 'Last refresh: Never';
      return;
    }
    
    const now = Date.now();
    const diff = now - timestamp;
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    
    let timeAgo;
    if (seconds < 60) {
      timeAgo = `${seconds} second${seconds !== 1 ? 's' : ''} ago`;
    } else if (minutes < 60) {
      timeAgo = `${minutes} minute${minutes !== 1 ? 's' : ''} ago`;
    } else if (hours < 24) {
      timeAgo = `${hours} hour${hours !== 1 ? 's' : ''} ago`;
    } else {
      const date = new Date(timestamp);
      timeAgo = date.toLocaleString();
    }
    
    lastRefreshText.textContent = `Last refresh: ${timeAgo}`;
  }
  
  // Update status display
  function updateStatus() {
    if (enableToggle.checked) {
      const interval = parseFloat(intervalSelect.value);
      let displayText;
      if (interval < 1) {
        displayText = `${Math.round(interval * 60)} sec`;
      } else if (interval === 1) {
        displayText = '1 min';
      } else {
        displayText = `${interval} min`;
      }
      statusText.textContent = `Status: Active (${displayText})`;
      statusText.className = 'enabled';
    } else {
      statusText.textContent = 'Status: Disabled';
      statusText.className = 'disabled';
    }
  }
  
  // Save settings to storage
  function saveSettings() {
    const settings = {
      enabled: enableToggle.checked,
      interval: parseFloat(intervalSelect.value)
    };
    
    chrome.storage.sync.set(settings, () => {
      updateStatus();
      showNotification('Settings saved!');
    });
  }
  
  // Show temporary notification
  function showNotification(message) {
    const originalText = saveSettingsBtn.textContent;
    saveSettingsBtn.textContent = message;
    saveSettingsBtn.style.backgroundColor = '#218838';
    
    setTimeout(() => {
      saveSettingsBtn.textContent = originalText;
      saveSettingsBtn.style.backgroundColor = '';
    }, 1500);
  }
  
  // Refresh now button handler
  function refreshNow() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const currentTab = tabs[0];
      
      // Check if we're on a supported page (with or without query parameters)
      const url = currentTab.url || '';
      const isSecurityPage = url.includes('security.microsoft.com/incidents') || 
                             url.includes('mto.security.microsoft.com/incidents');
      
      if (isSecurityPage) {
        chrome.tabs.sendMessage(currentTab.id, { action: 'manualRefresh' }, (response) => {
          if (chrome.runtime.lastError) {
            showRefreshNotification('Error: Reload the page first', false);
          } else if (response && response.success) {
            showRefreshNotification('Refreshed!', true);
            chrome.storage.sync.get(['lastRefresh'], (result) => {
              updateLastRefresh(result.lastRefresh);
            });
          } else {
            showRefreshNotification('Refresh button not found', false);
          }
        });
      } else {
        showRefreshNotification('Navigate to incidents page', false);
      }
    });
  }
  
  // Show refresh notification
  function showRefreshNotification(message, success) {
    const originalText = refreshNowBtn.textContent;
    refreshNowBtn.textContent = message;
    refreshNowBtn.style.backgroundColor = success ? '#28a745' : '#dc3545';
    
    setTimeout(() => {
      refreshNowBtn.textContent = originalText;
      refreshNowBtn.style.backgroundColor = '';
    }, 2000);
  }
  
  // Event listeners
  enableToggle.addEventListener('change', () => {
    updateStatus();
    saveSettings();
  });
  
  intervalSelect.addEventListener('change', () => {
    updateStatus();
  });
  
  saveSettingsBtn.addEventListener('click', saveSettings);
  refreshNowBtn.addEventListener('click', refreshNow);
  
  // Listen for storage changes to update last refresh
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'sync' && changes.lastRefresh) {
      updateLastRefresh(changes.lastRefresh.newValue);
    }
  });
  
  // Initialize
  loadSettings();
});
