// Background service worker for the extension
// Handles extension lifecycle and initialization

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    // Set default settings on first install
    chrome.storage.sync.set({
      enabled: false,
      interval: 5
    }, () => {
      console.log('[Security Refresh] Extension installed with default settings');
    });
  } else if (details.reason === 'update') {
    console.log('[Security Refresh] Extension updated');
  }
});

// Log when extension starts
console.log('[Security Refresh] Background service worker started');
