// Content script that runs on Microsoft Security incidents pages
// Handles automatic refresh by clicking the refresh button

let refreshInterval = null;
let isEnabled = false;
let intervalMinutes = 5; // default

// Function to find and click the refresh button
function clickRefreshButton() {
  try {
    // Try to find the button by the span with class "ms-Button-label"
    const refreshSpans = document.querySelectorAll('span.ms-Button-label');
    
    for (const span of refreshSpans) {
      if (span.textContent.trim() === 'Refresh') {
        // Find the parent button element
        const button = span.closest('button');
        if (button && !button.disabled) {
          console.log('[Security Refresh] Clicking refresh button');
          button.click();
          // Save last refresh timestamp
          chrome.storage.sync.set({ lastRefresh: Date.now() });
          return true;
        }
      }
    }
    
    // Alternative: search by ID pattern if the above doesn't work
    const spanById = document.querySelector('span[id*="id__"]');
    if (spanById && spanById.textContent.trim() === 'Refresh') {
      const button = spanById.closest('button');
      if (button && !button.disabled) {
        console.log('[Security Refresh] Clicking refresh button (by ID)');
        button.click();
        // Save last refresh timestamp
        chrome.storage.sync.set({ lastRefresh: Date.now() });
        return true;
      }
    }
    
    console.log('[Security Refresh] Refresh button not found or disabled');
    return false;
  } catch (error) {
    console.error('[Security Refresh] Error clicking refresh button:', error);
    return false;
  }
}

// Start the auto-refresh interval
function startAutoRefresh() {
  if (refreshInterval) {
    clearInterval(refreshInterval);
  }
  
  if (isEnabled && intervalMinutes > 0) {
    const intervalMs = intervalMinutes * 60 * 1000;
    const displayTime = intervalMinutes < 1 
      ? `${Math.round(intervalMinutes * 60)} second(s)` 
      : `${intervalMinutes} minute(s)`;
    console.log(`[Security Refresh] Starting auto-refresh every ${displayTime}`);
    
    refreshInterval = setInterval(() => {
      clickRefreshButton();
    }, intervalMs);
  }
}

// Stop the auto-refresh interval
function stopAutoRefresh() {
  if (refreshInterval) {
    console.log('[Security Refresh] Stopping auto-refresh');
    clearInterval(refreshInterval);
    refreshInterval = null;
  }
}

// Load settings from storage
function loadSettings() {
  chrome.storage.sync.get(['enabled', 'interval'], (result) => {
    isEnabled = result.enabled !== undefined ? result.enabled : false;
    intervalMinutes = result.interval !== undefined ? result.interval : 5;
    
    const displayTime = intervalMinutes < 1 
      ? `${Math.round(intervalMinutes * 60)} sec` 
      : `${intervalMinutes} min`;
    console.log(`[Security Refresh] Settings loaded - Enabled: ${isEnabled}, Interval: ${displayTime}`);
    
    if (isEnabled) {
      startAutoRefresh();
    } else {
      stopAutoRefresh();
    }
  });
}

// Listen for settings changes
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'sync') {
    if (changes.enabled) {
      isEnabled = changes.enabled.newValue;
      console.log(`[Security Refresh] Enabled changed to: ${isEnabled}`);
    }
    if (changes.interval) {
      intervalMinutes = changes.interval.newValue;
      const displayTime = intervalMinutes < 1 
        ? `${Math.round(intervalMinutes * 60)} sec` 
        : `${intervalMinutes} min`;
      console.log(`[Security Refresh] Interval changed to: ${displayTime}`);
    }
    
    // Restart with new settings
    if (isEnabled) {
      startAutoRefresh();
    } else {
      stopAutoRefresh();
    }
  }
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'manualRefresh') {
    const success = clickRefreshButton();
    sendResponse({ success: success });
  } else if (request.action === 'getStatus') {
    sendResponse({ 
      enabled: isEnabled, 
      interval: intervalMinutes,
      hasInterval: refreshInterval !== null
    });
  }
  return true;
});

// Initialize on load
console.log('[Security Refresh] Content script loaded');
loadSettings();

// Cleanup on unload
window.addEventListener('beforeunload', () => {
  stopAutoRefresh();
});
